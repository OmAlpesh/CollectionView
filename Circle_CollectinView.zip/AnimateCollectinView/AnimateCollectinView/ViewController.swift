//
//  ViewController.swift
//  AnimateCollectinView
//
//  Created by alpesh patel on 9/15/17.
//  Copyright © 2017 alpesh patel. All rights reserved.
//

import UIKit
import CPCollectionViewWheelLayoutSwift

class ViewController: UIViewController, UICollectionViewDataSource {
    
    fileprivate let reuseIdentifier = "CPCollectionViewCell"
    var colletionView:UICollectionView!
    var itemsArray = [String]()
    
    open var wheelType = CPWheelLayoutType.leftCenter
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // load data
        for item in 0...20 {
            itemsArray.append(String(item))
        }
        
        // setup views
        let configuration = CPWheelLayoutConfiguration.init(withCellSize: CGSize.init(width: 100, height: 100), radius: 200, angular: 30, wheelType:wheelType)
        let wheelLayout = CPCollectionViewWheelLayout.init(withConfiguration: configuration)
        colletionView = UICollectionView.init(frame: view.frame, collectionViewLayout:wheelLayout)
        colletionView.showsVerticalScrollIndicator = false
        colletionView.showsHorizontalScrollIndicator = false
        colletionView.backgroundColor = .white
        colletionView.register(CPCollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        colletionView.dataSource = self
        view.addSubview(colletionView)
        view.sendSubview(toBack: colletionView)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! CPCollectionViewCell
        cell.textLabel.text = itemsArray[indexPath.row]
        return cell
    }
    
    @IBAction func cellSizeChanged(_ sender: UISlider) {
        var configuration = (colletionView.collectionViewLayout as! CPCollectionViewWheelLayout).configuration
        configuration.cellSize = CGSize.init(width: Double(sender.value), height: Double(sender.value))
        updateCollectionView(withLayoutConfiguration: configuration)
    }
    
    @IBAction func angularViewChanged(_ sender: UISlider) {
        var configuration = (colletionView.collectionViewLayout as! CPCollectionViewWheelLayout).configuration
        configuration.angular = Double(sender.value)
        updateCollectionView(withLayoutConfiguration: configuration)
    }
    
    @IBAction func radiusValueChanged(_ sender: UISlider) {
        var configuration = (colletionView.collectionViewLayout as! CPCollectionViewWheelLayout).configuration
        configuration.radius = Double(sender.value)
        updateCollectionView(withLayoutConfiguration: configuration)
    }
    
    func updateCollectionView(withLayoutConfiguration configuration:CPWheelLayoutConfiguration) {
        let newLayout = CPCollectionViewWheelLayout.init(withConfiguration: configuration)
        colletionView.collectionViewLayout.invalidateLayout()
        colletionView.collectionViewLayout = newLayout
        colletionView.reloadData()
    }
    
    @IBAction func dismissButtonTapped(_ sender: UIButton) {
        self.dismiss(animated: true) {
        }
    }
}

