//
//  CaregiverProfileViewController.swift
//  NuevacareClient
//
//  Created by Bhavik  on 06/10/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit

class CaregiverProfileViewController : UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var CertiView: UIView!
    @IBOutlet weak var Certibtn: UIButton!
    let TAGS = ["Tech","Design", "Humor","Travel", "Music", "Writing", "Social Media", "Life", "Education", "Edtech", "Photography", "Startup", "Poetry", "Female Founders", "Business", "Fiction", "Love", "Food", "Sports"]
    
    @IBOutlet weak var Skillview: UIView!
    @IBOutlet weak var Skilsbtn: UIButton!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var certifiColletionView : UICollectionView!
    @IBOutlet weak var flowLayout: FlowLayout!
    @IBOutlet weak var flowLayout1: FlowLayout!
    var sizingCell: TagCell?
    
    @IBOutlet weak var TopofView: NSLayoutConstraint!
    @IBOutlet weak var ViewTopCont: NSLayoutConstraint!
    var tags = [Tag]()
    
    @IBOutlet weak var FirstViewHeight: NSLayoutConstraint!
    @IBOutlet weak var HeightConst: NSLayoutConstraint!
    @IBOutlet weak var view1TopConst: NSLayoutConstraint!
    
    @IBOutlet weak var SkillHeight: NSLayoutConstraint!
    @IBOutlet weak var HeightofCertiview: NSLayoutConstraint!
    
    @IBOutlet weak var lblName : UILabel!
    @IBOutlet weak var lblGenderTitle : UILabel!
    @IBOutlet weak var lblHeightTitle : UILabel!
    @IBOutlet weak var lblWeightTitle : UILabel!
    @IBOutlet weak var lblGenderValue : UILabel!
    @IBOutlet weak var lblHeightValue : UILabel!
    @IBOutlet weak var lblWeightValue : UILabel!
    @IBOutlet weak var lblLangTitle : UILabel!
    @IBOutlet weak var lblLangValue : UILabel!
    @IBOutlet weak var lblEmailTitle : UILabel!
    @IBOutlet weak var lblEmailValue : UILabel!
    @IBOutlet weak var lblMobileTitle : UILabel!
    @IBOutlet weak var lblMobileValue : UILabel!
    @IBOutlet weak var lblCityTitle : UILabel!
    @IBOutlet weak var lblCityValue : UILabel!
    @IBOutlet weak var lblPostCodeTitle : UILabel!
    @IBOutlet weak var lblPostCodeValue : UILabel!
    @IBOutlet weak var lblSep:UILabel!
    
    
    //Dog,Time,Smoke
    @IBOutlet weak var lblTime : UILabel!
    @IBOutlet weak var lblDog : UILabel!
    @IBOutlet weak var lblSmokers : UILabel!
    @IBOutlet weak var imgPhoto : AsyncImageView!
    @IBOutlet weak var imgTime : UIImageView!
    @IBOutlet weak var imgDog : UIImageView!
    @IBOutlet weak var imgSmokers : UIImageView!
    @IBOutlet weak var imgCameraIcon : UIImageView!
    
    @IBOutlet weak var profileView : UIView!
    
    @IBOutlet weak var lblFirstLine : UILabel!
    
    @IBOutlet weak var imgCertiBadge : UIImageView!
    @IBOutlet weak var lblTitle          :   UILabel!
    
    var fromTrackLocation : Bool = false
    
    var viewProfileX : CGFloat = 0
    var viewSkillsX : CGFloat = 0
    var viewCertX : CGFloat = 0
    
    var viewProfileWidth : CGFloat = 0
    var viewSkillsWidth : CGFloat = 0
    var viewCertWidth : CGFloat = 0
    
    @IBOutlet weak var CNViewProfileTrailing: NSLayoutConstraint!
    @IBOutlet weak var CNViewProfileLeading: NSLayoutConstraint!
    
    @IBOutlet weak var CNViewSkillsLeading: NSLayoutConstraint!
    @IBOutlet weak var CNViewSkillsTrailing: NSLayoutConstraint!
    
    @IBOutlet weak var CNViewCertiLeading: NSLayoutConstraint!
    @IBOutlet weak var CNViewCertiTrailing: NSLayoutConstraint!
    
    var arrSkills : NSArray = ["Tech","Design", "Humor","Travel", "Music", "Writing", "Social Media", "Life", "Education", "Edtech", "Photography", "Startup", "Poetry", "Female Founders", "Business", "Fiction", "Love", "Food", "Sports"]
    
    //Boolean
    var  isProfileOpen : Bool = false
    var  isSkillsOpen :  Bool = false
    var  isCertifiOpen : Bool = false
    
    var imgStarView = UIImageView()
    
    //NSArray()
     var arrCertificate : NSArray = ["Chest X Ray","First Aid Box", "CRR Certification","Tube Test"]
    
    //Dictionary
    var bookCareGiverFinalDict = NSMutableDictionary()
    var bookCareGiverPerosnalDict = NSMutableDictionary()
    
    //Menu
    var menuView                 : MenuView!
    
    //MARK:View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblTime.text = ""
        lblSmokers.text = ""
        lblDog.text = ""
        
        setUpFont()
        
        DispatchQueue.main.async {
            self.setUpUI()
        }
        
        lblLangValue.text = ""
        lblEmailValue.text = ""
        lblCityValue.text = ""
        lblMobileValue.text = ""
        lblPostCodeValue.text = ""
        
        CertiView.layer.cornerRadius = 5.0
        Skillview.layer.cornerRadius = 5.0
        
        profileView.isUserInteractionEnabled = true
        profileView.layer.cornerRadius = 5.15
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(clickOnProfileView))
        profileView.addGestureRecognizer(tapGesture)
        
        
        //Skill Cell Register
        let cellNib = UINib(nibName: "TagCell", bundle: nil)
        self.collectionView.register(cellNib, forCellWithReuseIdentifier: "TagCell")
        self.collectionView.backgroundColor = UIColor.clear
        self.sizingCell = (cellNib.instantiate(withOwner: nil, options: nil) as NSArray).firstObject as! TagCell?
        self.flowLayout.sectionInset = UIEdgeInsetsMake(18,8,18,8) //18,8,18,8
        for name in TAGS {
            let tag = Tag()
            tag.name = name
            self.tags.append(tag)
        }
        
        if Constant.isiPhone_5{
            HeightConst.constant = 296
            ViewTopCont.constant = 427+45
            view1TopConst.constant = 465+45
            FirstViewHeight.constant = 341
            HeightofCertiview.constant = 220
        }else if Constant.isiPhone_6_Plus{
            ViewTopCont.constant = 580+45
            view1TopConst.constant = 625+45
        }else{
            ViewTopCont.constant = 520+45
            view1TopConst.constant = 560+45
            HeightofCertiview.constant = 250
        }
        
        viewProfileX = CNViewProfileLeading.constant
        viewSkillsX = CNViewSkillsLeading.constant
        viewCertX = CNViewCertiLeading.constant
        
        viewProfileWidth = CNViewProfileTrailing.constant
        viewSkillsWidth = CNViewSkillsTrailing.constant
        viewCertWidth = CNViewCertiTrailing.constant
        
        //Get Caregiver Profile Service Call
        getCareGiverProfileServiceCall()
        
        //Certificate Cell Register
        let cellCertiNib = UINib(nibName: "CertificateCell", bundle: nil)
        self.certifiColletionView.register(cellCertiNib, forCellWithReuseIdentifier: "CellIdentifier")
        self.certifiColletionView.backgroundColor = UIColor.clear
        self.flowLayout1.sectionInset = UIEdgeInsetsMake(10,0,0,0)
        certifiColletionView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        NotificationCenter.default.removeObserver(self)
    }
    

    //MARK:SetUP UI
    func setUpUI()
    {
        imgPhoto.layer.cornerRadius = imgPhoto.frame.height/2.0
        imgPhoto.layer.masksToBounds = true
        
        
        imgCameraIcon.isUserInteractionEnabled = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(CaregiverProfileViewController.clickOnPhoto))
        imgCameraIcon.addGestureRecognizer(tapGesture)
    }

    
    //MARK:Set Up Font
    func setUpFont(){
        
        if Constant.isiPhone_5 {
            lblName.font = UIFont(name: lblName.font.fontName, size: 14)
            lblTime.font = UIFont(name: lblTime.font.fontName, size: 11)
            lblDog.font = UIFont(name: lblDog.font.fontName, size: 11)
            lblSmokers.font = UIFont(name: lblSmokers.font.fontName, size: 11)
            
            lblWeightTitle.font = UIFont(name: lblWeightTitle.font.fontName, size: 12)
            lblHeightTitle.font = UIFont(name: lblHeightTitle.font.fontName, size: 12)
            lblGenderTitle.font = UIFont(name: lblGenderTitle.font.fontName, size: 12)
            lblEmailTitle.font = UIFont(name: lblEmailTitle.font.fontName, size: 12)
            lblMobileTitle.font = UIFont(name: lblMobileTitle.font.fontName, size: 12)
            lblCityTitle.font = UIFont(name: lblCityTitle.font.fontName, size: 12)
            lblPostCodeTitle.font = UIFont(name: lblPostCodeTitle.font.fontName, size: 12)
            lblLangTitle.font = UIFont(name: lblLangTitle.font.fontName, size: 12)

            
            lblWeightValue.font = UIFont(name: lblWeightValue.font.fontName, size: 13)
            lblHeightValue.font = UIFont(name: lblHeightValue.font.fontName, size: 13)
            lblGenderValue.font = UIFont(name: lblGenderValue.font.fontName, size: 13)
            lblLangValue.font = UIFont(name: lblLangValue.font.fontName, size: 13)
            lblEmailValue.font = UIFont(name: lblEmailValue.font.fontName, size: 13)
            lblMobileValue.font = UIFont(name: lblMobileValue.font.fontName, size: 13)
            lblCityValue.font = UIFont(name: lblCityValue.font.fontName, size: 13)
            lblPostCodeValue.font = UIFont(name: lblPostCodeValue.font.fontName, size: 13)
            
          
            Skilsbtn.titleLabel!.font = UIFont(name: Skilsbtn.titleLabel!.font.fontName, size: 13)
            Certibtn.titleLabel!.font = UIFont(name: Certibtn.titleLabel!.font.fontName, size: 13)
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 15.0)
            lblSep.font = UIFont(name: lblSep.font.fontName, size: 12.0)
        }
        else if Constant.isiPhone_6
        {
            lblName.font = UIFont(name: lblName.font.fontName, size: 18)
            lblTime.font = UIFont(name: lblTime.font.fontName, size: 12)
            lblDog.font = UIFont(name: lblDog.font.fontName, size: 12)
            lblSmokers.font = UIFont(name: lblSmokers.font.fontName, size: 12)
            
            lblWeightTitle.font = UIFont(name: lblWeightTitle.font.fontName, size: 14)
            lblHeightTitle.font = UIFont(name: lblHeightTitle.font.fontName, size: 14)
            lblGenderTitle.font = UIFont(name: lblGenderTitle.font.fontName, size: 14)
            lblEmailTitle.font = UIFont(name: lblEmailTitle.font.fontName, size: 14)
            lblMobileTitle.font = UIFont(name: lblMobileTitle.font.fontName, size: 14)
            lblCityTitle.font = UIFont(name: lblCityTitle.font.fontName, size: 14)
            lblPostCodeTitle.font = UIFont(name: lblPostCodeTitle.font.fontName, size: 14)
            lblLangTitle.font = UIFont(name: lblLangTitle.font.fontName, size: 14)

            
            lblWeightValue.font = UIFont(name: lblWeightValue.font.fontName, size: 15)
            lblHeightValue.font = UIFont(name: lblHeightValue.font.fontName, size: 15)
            lblGenderValue.font = UIFont(name: lblGenderValue.font.fontName, size: 15)
            lblLangValue.font = UIFont(name: lblLangValue.font.fontName, size: 15)
            lblEmailValue.font = UIFont(name: lblEmailValue.font.fontName, size: 15)
            lblMobileValue.font = UIFont(name: lblMobileValue.font.fontName, size: 15)
            lblCityValue.font = UIFont(name: lblCityValue.font.fontName, size: 15)
            lblPostCodeValue.font = UIFont(name: lblPostCodeValue.font.fontName, size: 15)
            
            Skilsbtn.titleLabel!.font = UIFont(name: Skilsbtn.titleLabel!.font.fontName, size: 16)
            Certibtn.titleLabel!.font = UIFont(name: Certibtn.titleLabel!.font.fontName, size: 16)
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 18.0)
            lblSep.font = UIFont(name: lblSep.font.fontName, size: 14.0)

        }
            
        else if Constant.isiPhone_6_Plus
        {
            lblName.font = UIFont(name: lblName.font.fontName, size: 20)
            lblTime.font = UIFont(name: lblTime.font.fontName, size: 13)
            lblDog.font = UIFont(name: lblDog.font.fontName, size: 13)
            lblSmokers.font = UIFont(name: lblSmokers.font.fontName, size: 13)
            
            lblWeightTitle.font = UIFont(name: lblWeightTitle.font.fontName, size: 15)
            lblHeightTitle.font = UIFont(name: lblHeightTitle.font.fontName, size: 15)
            lblGenderTitle.font = UIFont(name: lblGenderTitle.font.fontName, size: 15)
            lblEmailTitle.font = UIFont(name: lblEmailTitle.font.fontName, size: 15)
            lblMobileTitle.font = UIFont(name: lblMobileTitle.font.fontName, size: 15)
            lblCityTitle.font = UIFont(name: lblCityTitle.font.fontName, size: 15)
            lblPostCodeTitle.font = UIFont(name: lblPostCodeTitle.font.fontName, size: 15)
            lblLangTitle.font = UIFont(name: lblLangTitle.font.fontName, size: 15)

            
            lblWeightValue.font = UIFont(name: lblWeightValue.font.fontName, size: 16)
            lblHeightValue.font = UIFont(name: lblHeightValue.font.fontName, size: 16)
            lblGenderValue.font = UIFont(name: lblGenderValue.font.fontName, size: 16)
            lblLangValue.font = UIFont(name: lblLangValue.font.fontName, size: 16)
            lblEmailValue.font = UIFont(name: lblEmailValue.font.fontName, size: 16)
            lblMobileValue.font = UIFont(name: lblMobileValue.font.fontName, size: 16)
            lblCityValue.font = UIFont(name: lblCityValue.font.fontName, size: 16)
            lblPostCodeValue.font = UIFont(name: lblPostCodeValue.font.fontName, size: 16)

            
            
            Skilsbtn.titleLabel!.font = UIFont(name: Skilsbtn.titleLabel!.font.fontName, size: 18)
            Certibtn.titleLabel!.font = UIFont(name: Certibtn.titleLabel!.font.fontName, size: 18)
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size:20.0)
            lblSep.font = UIFont(name: lblSep.font.fontName, size: 15.0)
        }
    }
    
    
    //MARK:TapGesture Method (Click On Photo)
    func clickOnPhoto()
    {
        //Action sheet open
        print("ActionSheet")
        
        self.view.endEditing(true)
        
        let settingsActionSheet: UIAlertController = UIAlertController(title:nil, message:nil, preferredStyle:UIAlertControllerStyle.actionSheet)
        settingsActionSheet.addAction(UIAlertAction(title:"From Camera", style:UIAlertActionStyle.default, handler:{ action in
            self.cameraOpen()
        }))
        settingsActionSheet.addAction(UIAlertAction(title:"From Library", style:UIAlertActionStyle.default, handler:{ action in
            self.photoLibraryOpen()
            
        }))
        settingsActionSheet.addAction(UIAlertAction(title:"Cancel", style:UIAlertActionStyle.cancel, handler:nil))
        present(settingsActionSheet, animated:true, completion:nil)
        
    }
    
    //MARK:Photo Library Open
    
    func photoLibraryOpen()
    {
        print("Library Open")
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.savedPhotosAlbum){
            
            let imagePicker = UIImagePickerController()
            
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.savedPhotosAlbum;
            imagePicker.allowsEditing = true
            
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    //MARK:Camera Open
    
    func cameraOpen()
    {
        print("Camera Open")
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.savedPhotosAlbum){
            
            let imagePicker = UIImagePickerController()
            
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
            
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
     //MARK:ImagePicker Delegate Method
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            imgPhoto.image = self.correctlyOrientedImage(image: image)
        }
        
        picker.dismiss(animated: true, completion: nil);
        
        DispatchQueue.main.async {
            self.editProfilePicServiceCall()
        }

    }
    
    
    func correctlyOrientedImage(image : UIImage) -> UIImage {
        if image.imageOrientation == UIImageOrientation.up {
            return image
        }
        
        UIGraphicsBeginImageContextWithOptions(image.size, false, image.scale)
        image.draw(in: CGRect(x: 0, y: 0, width: image.size.width,height: image.size.height))
        let normalizedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext();
        
        return normalizedImage;
    }

    
    //MARK:Edit Profile Service Call
    func editProfilePicServiceCall()
    {
        if !SharedInstance.isReachable {
            Constant.alertView("", strMessage:AlertMessages.kInternetAlertMessage)
            return
        }
        
        DispatchQueue.main.async {
            MBProgressHUD.showAdded(to: self.view, animated:true)
        }
        
        let prameter : NSDictionary = [
            "caregiver_id" : UserDefaults.standard.value(forKey: Constant.KEY_CAREGIVERID) as! NSInteger!,
            "os_type" : 2,
        ]
        
        print(prameter)
        let webserviceOBJ : Webservice = Webservice()
        
        let arrImagesKey = [
            "caregiver_image",
        ]
        
        let arrImageValue = [
            self.imgPhoto.image
        ]
    

        webserviceOBJ.RequestForPostWithImages(strUrl: (WebserviceURL.kSaveProfileURL as NSString) as String, postData: prameter, aryImageKey: arrImagesKey as NSArray, aryImages:arrImageValue as NSArray){
            (responseDict, isSuccess) in
            
            if isSuccess {
                
                print(responseDict)
                
                if responseDict.value(forKey: "status") as! NSInteger == 1
                {
                    print("Success")
                    
                    Constant.alertView("", strMessage:"Profile updated successfully")
                }
            }
            DispatchQueue.main.async {
                MBProgressHUD.hide(for: self.view, animated: true)
            }
        
        }
    }

    //MARK:Collectionview Delegate And DataSource Method
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        
        if(collectionView == certifiColletionView)
        {
            return arrCertificate.count
        }
        else
        {
            return arrSkills.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if(collectionView == certifiColletionView)
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellIdentifier", for: indexPath as IndexPath) as! CertificateCell
            cell.certiName.text = (arrCertificate.object(at: indexPath.row) as! String)
            //cell.certiName.text = "Bhavik"
            return cell
        }
        else
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TagCell", for: indexPath as IndexPath) as! TagCell
            self.configureCell(cell: cell, forIndexPath: indexPath as NSIndexPath)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if(collectionView==certifiColletionView)
        {
            return CGSize(width: collectionView.frame.width, height: 30)
        }
        else
        {
            self.configureCell(cell: self.sizingCell!, forIndexPath: indexPath as NSIndexPath)
            return self.sizingCell!.systemLayoutSizeFitting(UILayoutFittingCompressedSize)
        }
    }

    //MARK:WebService Call
    func getCareGiverProfileServiceCall()
    {
        if !SharedInstance.isReachable {
            Constant.alertView("", strMessage:AlertMessages.kInternetAlertMessage)
            return
        }
        
        DispatchQueue.main.async {
            MBProgressHUD.showAdded(to: self.view, animated:true)
        }
        
        let websriveObj : Webservice = Webservice()
        
        let parameter  : NSDictionary = [
            "caregiver_id"     : UserDefaults.standard.value(forKey: Constant.KEY_CAREGIVERID) as! NSInteger!
            ]
        
        websriveObj.RequestForPost(url: WebserviceURL.kCareGiverProfileURL, postData: parameter) { (responseDict, isSuccess) in
            
            if isSuccess {
                
                if responseDict.value(forKey: "status") as! NSInteger == 1
                {
                    print("Success")
                    
                    let dict : NSDictionary = responseDict.value(forKey: "data") as! NSDictionary
                    print("dictionary:",dict)
                    
                    DispatchQueue.main.async {
                        
                        self.arrSkills = responseDict.value(forKey:"skills") as! NSArray
                        self.collectionView.reloadData()
                        
                        self.arrCertificate = responseDict.value(forKey:"Certificate") as! NSArray
                        self.certifiColletionView.reloadData()
                        
                        self.setCaregiverProfile(dict: dict)
                    }
                }
                else{
                    Constant.alertView("", strMessage: responseDict.value(forKey: "msg") as! String)
                }
            }
            
            DispatchQueue.main.async {
                 MBProgressHUD.hide(for: self.view, animated: true)
            }

        }
    }
    

    //MARK:Configure Cell
    func configureCell(cell: TagCell, forIndexPath indexPath: NSIndexPath) {
        cell.tagName.text = (arrSkills.object(at: indexPath.row) as! String)
        cell.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1)
    }
    
    
    //MARK:Click On Profile View
    func clickOnProfileView()
    {
        print("ProfileView Click")
        
        self.collectionView.contentOffset = CGPoint(x: 0, y: 0)
        
        CNViewProfileLeading.constant = viewProfileX
        CNViewProfileTrailing.constant = viewProfileWidth
        
        CNViewSkillsLeading.constant = viewSkillsX
        CNViewSkillsTrailing.constant = viewSkillsWidth
        
        CNViewCertiLeading.constant = viewCertX
        CNViewCertiTrailing.constant = viewCertWidth
        
        isProfileOpen = true
        isSkillsOpen = false
        isCertifiOpen = false
        
        if Constant.isiPhone_5{
            HeightConst.constant = 296
            ViewTopCont.constant = 427+45
            view1TopConst.constant = 465+45
            FirstViewHeight.constant = 341
            
        }else if Constant.isiPhone_6_Plus{
            HeightConst.constant = 348
            ViewTopCont.constant = 580+45
            view1TopConst.constant = 625+45
        }else{
            self.SkillHeight.constant = 348
            HeightConst.constant = 348
            ViewTopCont.constant = 520+45
            view1TopConst.constant = 560+45
            FirstViewHeight.constant = 341
        }
        UIView.animate(withDuration: 0.5) {
            self.view.layoutIfNeeded()
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35){
            self.collectionView.contentOffset = CGPoint(x: 0, y: 0)
        }

    }
    
    //MARK:Click On Skill
    @IBAction func Buttonclicked(sender: AnyObject) {
    
        if(arrSkills.count==0)
        {
            Constant.alertView("", strMessage:"No skills available")
            return
        }
        
        if(isSkillsOpen==false)
        {
            CNViewProfileLeading.constant = viewProfileX+5
            CNViewProfileTrailing.constant = viewProfileWidth+5
            
            CNViewSkillsLeading.constant = viewSkillsX
            CNViewSkillsTrailing.constant = viewSkillsWidth
            
            CNViewCertiLeading.constant = viewCertX
            CNViewCertiTrailing.constant = viewCertWidth
            
            
            isProfileOpen = false
            isSkillsOpen = true
            isCertifiOpen = false
        }
        
        UIView.animate(withDuration: 0.5) {
            if Constant.isiPhone_5{
                self.HeightConst.constant = 296
                self.TopofView.constant = 150
                self.view1TopConst.constant = 465+45
            }else if Constant.isiPhone_6_Plus{
                self.TopofView.constant = 155 //150
                self.view1TopConst.constant = 625+45
                self.SkillHeight.constant = 348
            }else{
                self.SkillHeight.constant = 348
                self.TopofView.constant = 155
                self.view1TopConst.constant = 560+45
            }
            self.view.layoutIfNeeded()
        }
    }
    
    //MARK:Click On Certificate
    @IBAction func button1Clicked(sender: AnyObject)
    {
        if(arrCertificate.count==0)
        {
            Constant.alertView("", strMessage:"No certificates available")
            return
        }
        
        if(isCertifiOpen==false)
        {
            CNViewProfileLeading.constant = viewProfileX+10
            CNViewProfileTrailing.constant = viewProfileWidth+10
            
            CNViewSkillsLeading.constant = viewSkillsX+5
            CNViewSkillsTrailing.constant = viewSkillsWidth+5
            
            CNViewCertiLeading.constant = viewCertX
            CNViewCertiTrailing.constant = viewCertWidth
            
            isProfileOpen = false
            isSkillsOpen = false
            isCertifiOpen = true
        }
        
        UIView.animate(withDuration: 0.5) {
            if Constant.isiPhone_5{
                self.HeightConst.constant = 200
                self.TopofView.constant = 150
                self.view1TopConst.constant = 188
            }else if Constant.isiPhone_6_Plus{
                self.TopofView.constant = 155 //150
                self.view1TopConst.constant = 200 //195
                self.HeightofCertiview.constant = 240
                self.SkillHeight.constant = 200
            }else{
                self.SkillHeight.constant = 200
                self.TopofView.constant = 155
                self.view1TopConst.constant = 195
            }
            self.view.layoutIfNeeded()
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35){
            self.collectionView.contentOffset = CGPoint(x: 0, y: 0)
        }
    }
    
    
    //MARK:Set Profile Detail
    func setCaregiverProfile(dict: NSDictionary)
    {
        if(arrCertificate.count == 0)
        {
            imgCertiBadge.isHidden = true
        }
        else
        {
            imgCertiBadge.isHidden = false
        }
        
        var fromstart : NSInteger = 0
        
        let strRating = dict.value(forKey:"rating") as! String
        
        let ratingCount  = (strRating as NSString).doubleValue
        
        let isInteger = floor(ratingCount) == ratingCount
        
        var totalCount : NSInteger = 0
        
        if(isInteger)
        {
            totalCount = (strRating as NSString).integerValue
            
            fromstart = (5-totalCount) + 1

            if(totalCount>0)
            {
                for i in fromstart...5 {
                    imgStarView = self.view.viewWithTag(i) as! UIImageView!
                    imgStarView.isHidden = false
                    
                    let imgGray = UIImage(named:"RatingIcon")
                    imgStarView.image = imgGray
                }
            }
        }
        else
        {
            totalCount = (strRating as NSString).integerValue
            
            fromstart = (5-totalCount)
            
            if(totalCount>0)
            {
                for i in fromstart...4 {
                    imgStarView = self.view.viewWithTag(i) as! UIImageView!
                    imgStarView.isHidden = false
                    
                    let imgGray = UIImage(named:"RatingIcon")
                    imgStarView.image = imgGray
                }
                
                imgStarView = self.view.viewWithTag(5) as! UIImageView!
                imgStarView.isHidden = false
                
                let imgGray = UIImage(named:"HalfRate")
                imgStarView.image = imgGray
            }
        }
        
        lblName.text = (dict.value(forKey: "firstname") as AnyObject).uppercased as String!

        let genderValue = dict.value(forKey: "gender") as! NSInteger
        
        if(genderValue==1)
        {
            lblGenderValue.text = "Male"
        }
        else if(genderValue==2)
        {
            lblGenderValue.text = "Female"
        }
        else
        {
            lblGenderValue.text = ""
        }
        
        lblEmailValue.text = dict.value(forKey:"email") as! NSString as String
        lblMobileValue.text = dict.value(forKey:"mobileno") as! NSString as String
        lblCityValue.text = dict.value(forKey:"city") as! NSString as String
        lblPostCodeValue.text = dict.value(forKey:"pincode") as! NSString as String
        
        
        lblHeightValue.text = dict.value(forKey: "height") as! NSString as String
        lblWeightValue.text = String(format: "%@ lbs", dict.value(forKey: "weight") as! NSString as String)
        
        lblLangValue.text = dict.value(forKey:"language") as! NSString as String
        imgPhoto.imageURL = NSURL(string: dict.value(forKey: "caregiver_thumb_image") as! NSString as String) as URL!
        
        if(dict.value(forKey: "shifts") as! String == "TRUE")
        {
            lblTime.text = "Can work live in shifts"
        }
        else
        {
             lblTime.text = "Can work in hourly"
        }
        
        if(dict.value(forKey: "Dogs") as! String == "TRUE" && dict.value(forKey: "Cats") as! String == "TRUE" )
        {
            lblDog.text = "Can work with Pets"
        }
        else if(dict.value(forKey: "Dogs") as! String == "TRUE")
        {
            lblDog.text = "Can work with Dogs"
        }
        else if(dict.value(forKey: "Cats") as! String == "TRUE")
        {
            lblDog.text = "Can work with Cats"
        }
        else
        {
            lblDog.text = "Can't work with Pets"
        }
        
        if(dict.value(forKey: "Smoking") as! String == "TRUE")
        {
            lblSmokers.text = "Can work with Smokers"
        }
        else
        {
            lblSmokers.text = "Can't work with Smokers"
        }
    }

    //MARK:ClickOn Back
    @IBAction func clickOnBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
        
        
}
