//
//  CertificateCell.swift
//  NuevacareClient
//
//  Created by Bhavik  on 12/10/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit

class CertificateCell: UICollectionViewCell {

    @IBOutlet weak var certiName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()

        //Certificate Cell Font Size
        if(Constant.isiPhone_5)
        {
            self.certiName.font =  UIFont(name: self.certiName.font.fontName, size: 13.0)
        }
        else if(Constant.isiPhone_6)
        {
            self.certiName.font =  UIFont(name: self.certiName.font.fontName, size: 15.0)
        }
        else
        {
            self.certiName.font =  UIFont(name: self.certiName.font.fontName, size: 17.0)
        }
    }
}
