//
//  Tag.swift
//  TagFlowLayout
//
//  Created by Diep Nguyen Hoang on 7/30/15.
//  Copyright (c) 2015 CodenTrick. All rights reserved.


class Tag {
    
    var name: String?
    var selected = false
}
