//
//  TagCell.swift
//  TagFlowLayout
//
//  Created by Diep Nguyen Hoang on 7/30/15.
//  Copyright (c) 2015 CodenTrick. All rights reserved.
//

import UIKit

class TagCell: UICollectionViewCell {
    
    @IBOutlet weak var tagName: UILabel!
    @IBOutlet weak var tagNameMaxWidthConstraint: NSLayoutConstraint!
    
    override func awakeFromNib() {
        
        self.layer.cornerRadius = 5.0
        self.layer.borderWidth = 1.0
        self.layer.borderColor =  UIColor(red: 167/255, green: 165/255, blue: 167/255, alpha: 1).cgColor
        self.tagNameMaxWidthConstraint.constant = (UIScreen.main.bounds.width) - 8 * 2 - 8 * 2
        
        //Tag Name Font
        if(Constant.isiPhone_5)
        {
            self.tagName.font =  UIFont(name: self.tagName.font.fontName, size: 13.0)
        }
        else if(Constant.isiPhone_6)
        {
            self.tagName.font =  UIFont(name: self.tagName.font.fontName, size: 15.0)
        }
        else
        {
            self.tagName.font =  UIFont(name: self.tagName.font.fontName, size: 17.0)
        }
    }
}
