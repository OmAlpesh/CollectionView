//
//  CalendarCell.swift
//  NuevacareClient
//
//  Created by Bhavik  on 29/08/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit

class CalendarCell: UICollectionViewCell {

   //IBOutlets
   @IBOutlet weak var lblMMM       :   UILabel!
   @IBOutlet weak var lblDD        :   UILabel!
    
    //MARK:Initial Method
    override func awakeFromNib() {
        super.awakeFromNib()
        
        if(Constant.isiPhone_6) 
        {
            self.lblMMM.font = UIFont(name: lblMMM.font.fontName, size: 14)
            self.lblDD.font = UIFont(name: lblMMM.font.fontName, size: 15)
        }
        if(Constant.isiPhone_6_Plus)
        {
            self.lblMMM.font = UIFont(name: lblMMM.font.fontName, size: 14)
            self.lblDD.font = UIFont(name: lblMMM.font.fontName, size: 16)
        }
        if(Constant.isiPhone_5)
        {
            self.lblMMM.font = UIFont(name: lblMMM.font.fontName, size: 11)
            self.lblDD.font = UIFont(name: lblMMM.font.fontName, size: 13)
        }
    }
}
