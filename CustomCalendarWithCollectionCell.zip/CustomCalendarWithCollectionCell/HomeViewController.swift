//
//  HomeViewController.swift
//  NuevacareCaregiver
//
//  Created by Bhavik  on 07/12/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{

    //IBOutlets
    @IBOutlet weak var btnMenu  : UIButton!
    @IBOutlet weak var lblDate : UILabel!
    @IBOutlet weak var lblTitle : UILabel!
    @IBOutlet weak var homecollectionView : UICollectionView!
    @IBOutlet weak var tblSchedule : UITableView!
    @IBOutlet weak var lblNoSchedule : UILabel!
    
    //Variable
    var menuView                 : MenuView!
    var aryDates = NSMutableArray()
    var arrScheduleList = NSArray()
    var arrScheduleListIndexWise = NSArray()
    var arrStartTime = NSMutableArray()
    var preIndexPath : NSIndexPath!
    var doubleLat:String = ""
    var doubleLong:String = ""
    var curTime:String = ""
    var curDate:String = ""
    
    var startDate:String = ""
    
    var  isDateMatch : Bool = false
    var  isRefreshList : Bool = false
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblDate.backgroundColor = UIColor.clear
        
        setUPFont()
        setUPCollectionView()
        setUPTableView()
        myScheduleWebservice()
        
        if SharedInstance.isLaunch == true {
                        
            SharedInstance.isLaunch = false
            
            UIApplication.shared.applicationIconBadgeNumber = 0
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.badgeCountZeroServiceCall()
        }
    }
    
    //MARK:Refresh HomeView
    func refreshList(notification: NSNotification){
        
        print("refreshList called")
        //print(notification.userInfo ?? "")
        
        let userInfo : [String:String?] = notification.userInfo as! [String:String?]
        startDate = userInfo["string"]!!
        
        print(startDate)
        
        isRefreshList = true
        
        myScheduleWebservice()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        UIApplication.shared.statusBarStyle = .default
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(removeTransparentView),
            name:NSNotification.Name(rawValue: "RemoveTransparentView"),
            object: nil)
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(refreshList),
            name:NSNotification.Name(rawValue: "ScheduleNotification"),
            object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        NotificationCenter.default.removeObserver(self)
    }
    
    //MARK:Remove Transparent View
    @objc func removeTransparentView(notification: NSNotification){
        
        print(menuView)
        
        UIView.animate(withDuration: 0.3, animations: {
            self.menuView.frame = CGRect(x: self.menuView.frame.origin.x, y: UIScreen.main.bounds.size.height, width: self.menuView.frame.size.width, height: self.menuView.frame.size.height)
        }, completion: {
            (value: Bool) in
            self.btnMenu.isHidden = false
            self.menuView.removeFromSuperview()
            self.view.unBlur()
        })
    }
    
    //MARK Set Up Font
    
    func  setUPFont()
    {
        if(Constant.isiPhone_6_Plus)
        {
            lblDate.font =  UIFont(name:  lblDate.font.fontName, size: 14.0)
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 20.0)
            lblNoSchedule.font =  UIFont(name: lblNoSchedule.font.fontName, size: 18.0)
        }
        if(Constant.isiPhone_6)
        {
            lblDate.font =  UIFont(name:  lblDate.font.fontName, size: 13.0)
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 18.0)
            lblNoSchedule.font =  UIFont(name: lblNoSchedule.font.fontName, size: 16.0)
            
        }
        if(Constant.isiPhone_5)
        {
            lblDate.font =  UIFont(name:  lblDate.font.fontName, size: 11.0)
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 15.0)
            lblNoSchedule.font =  UIFont(name: lblNoSchedule.font.fontName, size: 13.0)
        }
    }
    
    //MARK:Set Up Calendar
    
    func setUPCalendar()
    {
        let now = NSDate()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MMM-dd"
        var date = NSDate()
        
        aryDates.removeAllObjects()
        
        for index in 1...7 {
            let dicDate = NSMutableDictionary()
            dateFormatter.dateFormat = "dd/MM/yyyy"
            
            dateFormatter.dateFormat = "E"
            dicDate["e"] = dateFormatter.string(from: date as Date)
           // dicDate["e"] = dateFormatter.stringFromDate(date)
            
            dateFormatter.dateFormat = "dd"
            dicDate["dd"] = dateFormatter.string(from: date as Date)
            
            dateFormatter.dateFormat = "yyyy"
            dicDate["yyyy"] = dateFormatter.string(from: date as Date)
            
            dateFormatter.dateFormat = "MMM"
            dicDate["MMM"] = dateFormatter.string(from: date as Date)
            
            dateFormatter.dateFormat = "MMMM"
            dicDate["MMMM"] = dateFormatter.string(from: date as Date)
            
            dateFormatter.dateFormat = "EEEE"
            dicDate["EEEE"] = dateFormatter.string(from: date as Date)
            
            aryDates.add(dicDate)
            
            date = now.addingTimeInterval(Double(index) * 24 * 60 * 60)
        }
        
        print("\(aryDates)")
        
        lblDate.text = String(format: "%@, %@ %@, %@",((aryDates.object(at: 0) as AnyObject).value(forKey:
            "EEEE") as AnyObject).uppercased as String!,((aryDates.object(at: 0) as AnyObject).value(forKey:"MMMM") as AnyObject).uppercased as String!,(aryDates.object(at: 0) as AnyObject).value(forKey: "dd") as! String!,(aryDates.object(at: 0) as AnyObject).value(forKey:"yyyy") as! String!)
    }
    
    //MARK:Set Up CollectionView
    func setUPCollectionView()
    {
        let flow = homecollectionView.collectionViewLayout as! UICollectionViewFlowLayout
        flow.sectionInset = UIEdgeInsetsMake(0, 12, 0, 0)
        self.homecollectionView.register(UINib(nibName:"CalendarCell",bundle: nil), forCellWithReuseIdentifier: "calendarcell")
        self.homecollectionView.backgroundColor = UIColor.clear
    }
    
    //MARK:Set Up TableView
    func  setUPTableView(){
        tblSchedule.register(UINib.init(nibName: "ScheduleListCell", bundle: nil), forCellReuseIdentifier: "ScheduleListCell")
        tblSchedule.tableFooterView = UIView()
        tblSchedule.estimatedRowHeight = 102.0
        tblSchedule.rowHeight = UITableViewAutomaticDimension
    }
    
    //MARK:Click On Menu
    @IBAction func clickOnMenu(sender:AnyObject) {
        
        self.btnMenu.isHidden = true
        
        self.view.blur(blurRadius:3) //Blur View
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.menuView = Bundle.main.loadNibNamed("MenuView", owner: nil, options: nil)![0] as! MenuView
            let initialframe = self.menuView.frame
            self.menuView.frame = CGRect(x: self.menuView.frame.origin.x, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
            
            print(self.menuView.frame)
            
            UIView.beginAnimations(nil, context: nil)
            UIView.setAnimationDuration(0.4)
            self.menuView.frame = CGRect(x: self.menuView.frame.origin.x, y: initialframe.origin.y, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
            UIView.commitAnimations()
            print(self.menuView.frame)
            UIApplication.shared.keyWindow!.addSubview(self.menuView)
        }
    }
    
    //MARK:UICollectionView DataSource And Delegate Method
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize
    {
        return CGSize(width: UIScreen.main.bounds.size.width/7, height: 60)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: "calendarcell", for: indexPath as IndexPath) as! CalendarCell
        
        cell.backgroundColor = UIColor.clear
        
        cell.lblDD.backgroundColor = UIColor.clear
        
        cell.lblDD.text = (aryDates.object(at:indexPath.row) as AnyObject).value(forKey:"dd") as! String!
        cell.lblMMM.text = ((aryDates.object(at: indexPath.row) as AnyObject).value(forKey:"e") as AnyObject).uppercased as String!
                
        let str = (aryDates.object(at:indexPath.row) as AnyObject).value(forKey:"e") as! String
        
        if(str.characters.last == ".")
        {
            cell.lblMMM.text = String((((self.aryDates.object(at: indexPath.row) as AnyObject).value(forKey:"e") as AnyObject).uppercased as String!).characters.dropLast())
        }
        else
        {
            cell.lblMMM.text = ((self.aryDates.object(at: indexPath.row) as AnyObject).value(forKey:"e") as AnyObject).uppercased as String!
        }
    
        if ((arrScheduleList.object(at: indexPath.row) as AnyObject).count>0)
        {
            cell.lblDD.textColor = UIColor(red: 65/255, green: 90/255, blue: 104/255, alpha: 1)
        }
        else
        {
            cell.lblDD.textColor = UIColor(red: 177/255, green: 177/255, blue: 177/255, alpha: 1)
        }
        
        if(indexPath.row==0)
        {
            if(Constant.isiPhone_6)
            {
                cell.lblDD.font = UIFont(name: cell.lblDD.font.fontName, size: 16)
            }
            if(Constant.isiPhone_6_Plus)
            {
                cell.lblDD.font = UIFont(name: cell.lblDD.font.fontName, size: 17)
            }
            if(Constant.isiPhone_5)
            {
                cell.lblDD.font = UIFont(name: cell.lblDD.font.fontName, size: 14)
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath)
    {
    
        print("collectionview indexpath:",indexPath.row)
        
        let preCell  = collectionView.cellForItem(at: preIndexPath as IndexPath) as! CalendarCell
        preCell.lblDD.backgroundColor = UIColor.clear
        preCell.lblDD.layer.cornerRadius = 0
        
        if ((arrScheduleList.object(at: preIndexPath.row) as AnyObject).count>0)
        {
            preCell.lblDD.textColor = UIColor(red: 65/255, green: 90/255, blue: 104/255, alpha: 1)
        }
        else
        {
            preCell.lblDD.textColor = UIColor(red: 177/255, green: 177/255, blue: 177/255, alpha: 1)
        }
        
        if(Constant.isiPhone_6)
        {
            preCell.lblDD.font = UIFont(name: preCell.lblDD.font.fontName, size: 15)
        }
        if(Constant.isiPhone_6_Plus)
        {
            preCell.lblDD.font = UIFont(name: preCell.lblDD.font.fontName, size: 16)
        }
        if(Constant.isiPhone_5)
        {
            preCell.lblDD.font = UIFont(name: preCell.lblDD.font.fontName, size: 13)
        }
        
        //245 128 38
         lblDate.text = String(format: "%@, %@ %@, %@",((aryDates.object(at: indexPath.row) as AnyObject).value(forKey:
            "EEEE") as AnyObject).uppercased as String!,((aryDates.object(at: indexPath.row) as AnyObject).value(forKey:"MMMM") as AnyObject).uppercased as String!,(aryDates.object(at: indexPath.row) as AnyObject).value(forKey: "dd") as! String!,(aryDates.object(at: indexPath.row) as AnyObject).value(forKey:"yyyy") as! String!)
        
        let cell  = collectionView.cellForItem(at: indexPath as IndexPath) as! CalendarCell
        cell.lblDD.layer.cornerRadius = cell.lblDD.frame.size.width/2
        cell.lblDD.layer.masksToBounds = true
        cell.lblDD.backgroundColor = UIColor(red: 245/255, green: 128/255, blue: 38/255, alpha: 1)
        cell.lblDD.textColor = UIColor.white
        
        if(Constant.isiPhone_6)
        {
            cell.lblDD.font = UIFont(name: cell.lblDD.font.fontName, size: 16)
        }
        if(Constant.isiPhone_6_Plus)
        {
            cell.lblDD.font = UIFont(name: cell.lblDD.font.fontName, size: 17)
        }
        if(Constant.isiPhone_5)
        {
            cell.lblDD.font = UIFont(name: cell.lblDD.font.fontName, size: 14)
        }
        
        if(arrScheduleListIndexWise.count>0)
        {
            arrScheduleListIndexWise = NSArray()
        }
        if ((arrScheduleList.object(at: indexPath.row)) as AnyObject).count > 0
        {
            arrScheduleListIndexWise = arrScheduleList.object(at: indexPath.row) as! NSArray
            self.lblNoSchedule.isHidden = true
            self.tblSchedule.isHidden = false
            self.tblSchedule.reloadData()
        }
            
        else
        {
            self.lblNoSchedule.isHidden = false
            self.tblSchedule.isHidden = true
        }
        
        preIndexPath = indexPath
      
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return self.aryDates.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAtIndex section: Int) -> UIEdgeInsets {
        return UIEdgeInsetsMake(0, 0, 0, 0)
    }
    
    //MARK:My Schedule Web Service
    func myScheduleWebservice()
    {
        if !SharedInstance.isReachable {
            Constant.alertView("", strMessage:AlertMessages.kInternetAlertMessage)
            return
        }
        
         DispatchQueue.main.async {
            MBProgressHUD.showAdded(to: self.view, animated:true)
        }
        
        let date = NSDate()
        
        let formatter = DateFormatter()
        formatter.dateFormat = "YYYY-MM-dd HH:mm:ss"
        let defaultTimeZoneStr = formatter.string(from: date as Date)
        formatter.timeZone =  NSTimeZone(name:"America/Los_Angeles") as TimeZone! //America/Los_Angeles
        var utcTimeZoneStr = NSString()
        utcTimeZoneStr = formatter.string(from: date as Date) as NSString
        
        print(defaultTimeZoneStr)
        print(utcTimeZoneStr)
        
        let websriveObj : Webservice = Webservice()
        
        let parameter  : NSDictionary = [
            "caregiver_id"     : UserDefaults.standard.value(forKey: Constant.KEY_CAREGIVERID) as! NSInteger! ,
            "current_datetime"  : utcTimeZoneStr,
            ]
        
        websriveObj.RequestForPost(url: WebserviceURL.kMyScheduleURL, postData: parameter) { (responseDict, isSuccess) in
            
            if isSuccess {
                
                if responseDict.value(forKey: "status") as! NSInteger == 1
                {
                    print("Success")
                
                    self.arrScheduleList = responseDict.value(forKey: "data") as! NSArray
                    
                    print(self.arrScheduleList)
                    
                    if ((self.arrScheduleList.object(at: 0)) as AnyObject).count > 0
                    {
                        self.lblNoSchedule.isHidden = true
                        self.arrScheduleListIndexWise = self.arrScheduleList.object(at: 0) as! NSArray
                        
                        DispatchQueue.main.async {
                            self.lblNoSchedule.isHidden = true
                            self.tblSchedule.isHidden = false
                            self.tblSchedule.reloadData()
                        }
                    }
                    else
                    {
                        
                        DispatchQueue.main.async {
                            self.tblSchedule.isHidden = true
                            self.lblNoSchedule.isHidden = false
                        }
                    }
                    DispatchQueue.main.async {
                        
                        if(SharedInstance.isNotification == false)
                        {
                            self.setUPCalendar()
                            self.homecollectionView.reloadData()
                            
                            self.homecollectionView.performBatchUpdates({ }, completion: {(Bool) in
                                let indexPath = IndexPath(row:0 ,section:0)
                                let cell  = self.homecollectionView.cellForItem(at: indexPath) as! CalendarCell
                                cell.lblDD.layer.cornerRadius = cell.lblDD.frame.size.width/2
                                cell.lblDD.layer.masksToBounds = true
                                cell.lblDD.backgroundColor = UIColor(red: 245/255, green: 128/255, blue: 38/255, alpha: 1)
                                cell.lblDD.textColor = UIColor.white
                                self.preIndexPath = indexPath as NSIndexPath!
                            })
                        }
                        else
                        {
                            if(self.isRefreshList)
                            {
                                self.isRefreshList = false
                                SharedInstance.isNotification = false
                                self.homecollectionView.reloadData()
                                
                                self.homecollectionView.performBatchUpdates({ }, completion: {(Bool) in
                                    self.handleNotification()
                                })
                            }
                            else
                            {
                                self.setUPCalendar()
                                self.homecollectionView.reloadData()
                                
                                self.homecollectionView.performBatchUpdates({ }, completion: {(Bool) in
                                    SharedInstance.isNotification = false
                                    self.handleNotification()
                                })
                            }
                        }
                    }
                }
                else{
                    Constant.alertView("", strMessage: responseDict.value(forKey: "msg") as! String)
                }
            }
            
            DispatchQueue.main.async {
                 MBProgressHUD.hide(for: self.view, animated: true)
            }
        }
    }
    
    //MARK:Handle Notification
    
    func handleNotification()
    {
        print(self.arrScheduleList)
        
        print(self.startDate)
        
        for i in 0 ..< self.arrScheduleList.count
        {
            if ((self.arrScheduleList.object(at: i) as AnyObject).count > 0)
            {
                var tempArray = NSArray()
                
                tempArray = self.arrScheduleList.object(at: i) as! NSArray
                
                print(tempArray)
                
                let dict : NSDictionary = tempArray.object(at: 0) as! NSDictionary
                
                if(dict.value(forKey:"date") as! String == self.startDate)
                {
                    if((preIndexPath == nil))
                    {
                        let indexPath = IndexPath(row:0 ,section:0)
                        self.preIndexPath = indexPath as NSIndexPath!
                    }
                    
                    print(homecollectionView)
                    //print(CalendarCell())
                    print(preIndexPath)
                    
                    let preCell  = self.homecollectionView.cellForItem(at: preIndexPath as IndexPath) as! CalendarCell
                    preCell.lblDD.backgroundColor = UIColor.clear
                    preCell.lblDD.layer.cornerRadius = 0
                    
                    if ((arrScheduleList.object(at: preIndexPath.row) as AnyObject).count>0)
                    {
                        preCell.lblDD.textColor = UIColor(red: 65/255, green: 90/255, blue: 104/255, alpha: 1)
                    }
                    else
                    {
                        preCell.lblDD.textColor = UIColor(red: 177/255, green: 177/255, blue: 177/255, alpha: 1)
                    }
                    if(Constant.isiPhone_6)
                    {
                        preCell.lblDD.font = UIFont(name: preCell.lblDD.font.fontName, size: 15)
                    }
                    if(Constant.isiPhone_6_Plus)
                    {
                        preCell.lblDD.font = UIFont(name: preCell.lblDD.font.fontName, size: 16)
                    }
                    if(Constant.isiPhone_5)
                    {
                        preCell.lblDD.font = UIFont(name: preCell.lblDD.font.fontName, size: 13)
                    }
                    
                    isDateMatch = true
                    
                    let indexPath = IndexPath(row:i ,section:0)
                    let cell  = self.homecollectionView.cellForItem(at: indexPath) as! CalendarCell
                    cell.lblDD.layer.cornerRadius = cell.lblDD.frame.size.width/2
                    cell.lblDD.layer.masksToBounds = true
                    cell.lblDD.backgroundColor = UIColor(red: 245/255, green: 128/255, blue: 38/255, alpha: 1)
                    cell.lblDD.textColor = UIColor.white
                    self.preIndexPath = indexPath as NSIndexPath!
                    
                    arrScheduleListIndexWise = arrScheduleList.object(at: indexPath.row) as! NSArray
                    
                    if(Constant.isiPhone_6)
                    {
                        cell.lblDD.font = UIFont(name: cell.lblDD.font.fontName, size: 16)
                    }
                    if(Constant.isiPhone_6_Plus)
                    {
                        cell.lblDD.font = UIFont(name: cell.lblDD.font.fontName, size: 17)
                    }
                    if(Constant.isiPhone_5)
                    {
                        cell.lblDD.font = UIFont(name: cell.lblDD.font.fontName, size: 14)
                    }
                    
                    
                    self.lblDate.text = String(format: "%@, %@ %@, %@",((self.aryDates.object(at: i) as AnyObject).value(forKey:
                        "EEEE") as AnyObject).uppercased as String!,((self.aryDates.object(at: i) as AnyObject).value(forKey:"MMMM") as AnyObject).uppercased as String!,(self.self.aryDates.object(at: i) as AnyObject).value(forKey: "dd") as! String!,(self.aryDates.object(at: i) as AnyObject).value(forKey:"yyyy") as! String!)
                    
                    break
                }
            }
        }
        
        if(isDateMatch==false)
        {
            if((preIndexPath == nil))
            {
                let indexPath = IndexPath(row:0 ,section:0)
                self.preIndexPath = indexPath as NSIndexPath!
            }
            
            let preCell  = self.homecollectionView.cellForItem(at: preIndexPath as IndexPath) as! CalendarCell
            preCell.lblDD.backgroundColor = UIColor.clear
            preCell.lblDD.layer.cornerRadius = 0
            
            if ((arrScheduleList.object(at: preIndexPath.row) as AnyObject).count>0)
            {
                preCell.lblDD.textColor = UIColor(red: 65/255, green: 90/255, blue: 104/255, alpha: 1)
            }
            else
            {
                preCell.lblDD.textColor = UIColor(red: 177/255, green: 177/255, blue: 177/255, alpha: 1)
            }
            
            if(Constant.isiPhone_6)
            {
                preCell.lblDD.font = UIFont(name: preCell.lblDD.font.fontName, size: 15)
            }
            if(Constant.isiPhone_6_Plus)
            {
                preCell.lblDD.font = UIFont(name: preCell.lblDD.font.fontName, size: 16)
            }
            if(Constant.isiPhone_5)
            {
                preCell.lblDD.font = UIFont(name: preCell.lblDD.font.fontName, size: 13)
            }
            
            let indexPath = IndexPath(row:0 ,section:0)
            let cell  = self.homecollectionView.cellForItem(at: indexPath) as! CalendarCell
            cell.lblDD.layer.cornerRadius = cell.lblDD.frame.size.width/2
            cell.lblDD.layer.masksToBounds = true
            cell.lblDD.backgroundColor = UIColor(red: 245/255, green: 128/255, blue: 38/255, alpha: 1)
            cell.lblDD.textColor = UIColor.white
            self.preIndexPath = indexPath as NSIndexPath!
            
            if(Constant.isiPhone_6)
            {
                cell.lblDD.font = UIFont(name: cell.lblDD.font.fontName, size: 16)
            }
            if(Constant.isiPhone_6_Plus)
            {
                cell.lblDD.font = UIFont(name: cell.lblDD.font.fontName, size: 17)
            }
            if(Constant.isiPhone_5)
            {
                cell.lblDD.font = UIFont(name: cell.lblDD.font.fontName, size: 14)
            }
            
            self.lblDate.text = String(format: "%@, %@ %@, %@",((self.aryDates.object(at: 0) as AnyObject).value(forKey:
                "EEEE") as AnyObject).uppercased as String!,((self.aryDates.object(at: 0) as AnyObject).value(forKey:"MMMM") as AnyObject).uppercased as String!,(self.self.aryDates.object(at: 0) as AnyObject).value(forKey: "dd") as! String!,(self.aryDates.object(at: 0) as AnyObject).value(forKey:"yyyy") as! String!)
            
            self.lblNoSchedule.isHidden = false
            self.tblSchedule.isHidden = true
        }
        else
        {
            isDateMatch = false
            
            self.lblNoSchedule.isHidden = true
            self.tblSchedule.isHidden = false
            self.tblSchedule.reloadData()
            
        }
    }
    
    //MARK:-UITableViewDelegate & DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(arrScheduleListIndexWise.count)
        return arrScheduleListIndexWise.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 102.0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell  = tableView.dequeueReusableCell(withIdentifier: "ScheduleListCell", for: indexPath as IndexPath) as! ScheduleListCell
        
        cell.selectionStyle = .none
        
        let dict : NSDictionary = arrScheduleListIndexWise.object(at: indexPath.row) as! NSDictionary
        
        print(dict)
        
        var strStartTime = dict.value(forKey: "start_time")
        var strEndTime = dict.value(forKey: "end_time")
        
        strStartTime = self.convertTime(para: strStartTime! as! String)
        strEndTime  =  self.convertTime(para: strEndTime! as! String)
        
        cell.lblName.text = dict.value(forKey: "name") as? String
        cell.lblTime.text = String(format: "%@ - %@",strStartTime as! String,strEndTime as! String)
        
        cell.lblAddress.text = dict.value(forKey: "address") as? String
        
        let text = cell.lblAddress.text!
        let test = String(text.characters.filter { !" \n".characters.contains($0) })
        cell.lblAddress.text = test
        
        cell.lblCity.text = String(format:"%@,%@-%@", (dict.value(forKey: "city") as? String)!,(dict.value(forKey: "state") as? String)!,(dict.value(forKey: "pincode") as? String)!)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let storyboard = UIStoryboard(name: "NewStoryBoard", bundle: nil)
        
        let trackLocationVC = storyboard.instantiateViewController(withIdentifier: "TrackLocationViewController") as! TrackLocationViewController
        
        let dict : NSDictionary = arrScheduleListIndexWise.object(at: indexPath.row) as! NSDictionary
        trackLocationVC.dictdirection = dict
        trackLocationVC.caregiver_id = UserDefaults.standard.value(forKey: Constant.KEY_CAREGIVERID) as! NSInteger!
        
        self.navigationController?.pushViewController(trackLocationVC, animated: true)
    }
    
    //MARK:Convert String To Time
    func convertTime(para:String) -> String {
        let inFormatter = DateFormatter()
        inFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX") as Locale!
        inFormatter.dateFormat = "HH:mm:ss" //24 format
        
        let outFormatter = DateFormatter()
        outFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX") as Locale!
        outFormatter.dateFormat = "hh:mm a"
        
        let date = inFormatter.date(from: para)! as NSDate
        let outStr = outFormatter.string(from: date as Date) as String
        print(outStr) // -> outputs 04:50
        
        return outStr
    }
    
    //MARK:Click On Notification
    
    @IBAction func clickOnNotification(sender:AnyObject)
    {
        print("Notification")
        
        let NotifyVC = SharedInstance.storyboard?.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
        
        self.navigationController?.pushViewController(NotifyVC, animated: true)
    }
    
    //MARK:Save Where Is My Caregiver Detail
    
    func saveMyCareGiverDetail()
    {
        var selectedIndex = NSInteger()
        
        //Current Date Time
        
        let dateFormatter1 = DateFormatter()
        let strCurDateFromServer = String(format: "%@ %@",curDate,self.convertTime(para: curTime))
        
        dateFormatter1.dateFormat = "yyyy-MM-dd hh:mm a"
        dateFormatter1.timeZone =  NSTimeZone(name:"America/Los_Angeles") as TimeZone!//NSTimeZone(name:self.curTimeZone)
        
        let curServerDate = dateFormatter1.date(from: strCurDateFromServer)
        print("CurDate:",curServerDate ?? "")
        
        for i in 0 ..< arrScheduleListIndexWise.count {
            
            let dict : NSDictionary = arrScheduleListIndexWise.object(at: i) as! NSDictionary
            
            //Schedule Start Time
            var strStartTime = dict.value(forKey: "start_time") as! String
            
            strStartTime = String(format: "%@ %@",dict.value(forKey: "date") as! String!,self.convertTime(para: strStartTime))
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm a"
            dateFormatter.timeZone = NSTimeZone(name:"America/Los_Angeles") as TimeZone! //NSTimeZone(name:self.curTimeZone)
            
            let date = dateFormatter.date(from: strStartTime)
            print(date ?? "")
            
            self.arrStartTime.add(date!)
        }
        
        var flag : Bool = false
        
        for i in 0 ..< arrStartTime.count {
            
            if(curServerDate!.compare((arrStartTime.object(at: i) as! NSDate) as Date) == ComparisonResult.orderedDescending)
            {
                selectedIndex = i
                flag = true
                print(selectedIndex)
                break
            }
        }
        
        if(flag==false)
        {
            selectedIndex = 0
        }
        
        print(self.arrStartTime)
        
        let careGiverId = ((arrScheduleListIndexWise.object(at: selectedIndex) as AnyObject).value(forKey: "caregiver_id") as AnyObject)
        
        print(careGiverId)
        
        let dict : NSDictionary = arrScheduleListIndexWise.object(at: selectedIndex) as! NSDictionary
        
        SharedInstance.careGiverId = careGiverId as! NSInteger
        SharedInstance.careGiverDict = dict
        SharedInstance.strLatitude = doubleLat
        SharedInstance.strLongitude = doubleLong
    }
}
