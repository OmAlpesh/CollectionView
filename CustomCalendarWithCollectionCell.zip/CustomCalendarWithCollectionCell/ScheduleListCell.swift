//
//  ScheduleListCell.swift
//  NuevacareClient
//
//  Created by Bhavik  on 30/08/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit

class ScheduleListCell: UITableViewCell {
    
    //IBOutlets
    @IBOutlet weak var lblName       :   UILabel!
    @IBOutlet weak var lblTime       :   UILabel!
    @IBOutlet weak var lblAddress    :   UILabel!
    @IBOutlet weak var lblCity       :   UILabel!
    
    //MARK:Initial Method
    override func awakeFromNib() {
        super.awakeFromNib()
      
        if(Constant.isiPhone_6_Plus)
        {
            self.lblName.font = UIFont(name: lblName.font.fontName, size: 17)
            self.lblTime.font = UIFont(name: lblTime.font.fontName, size: 15)
            self.lblAddress.font = UIFont(name: lblAddress.font.fontName, size: 15)
            self.lblCity.font = UIFont(name: lblCity.font.fontName, size: 15)
        }
        else if(Constant.isiPhone_6)
        {
            self.lblName.font = UIFont(name: lblName.font.fontName, size: 16)
            self.lblTime.font = UIFont(name: lblTime.font.fontName, size: 14)
            self.lblAddress.font = UIFont(name: lblAddress.font.fontName, size: 14)
            self.lblCity.font = UIFont(name: lblCity.font.fontName, size: 14)

        }
        else if(Constant.isiPhone_5)
        {
            self.lblName.font = UIFont(name: lblName.font.fontName, size: 14)
            self.lblTime.font = UIFont(name: lblTime.font.fontName, size: 13)
            self.lblAddress.font = UIFont(name: lblAddress.font.fontName, size: 13)
            self.lblCity.font = UIFont(name: lblCity.font.fontName, size: 13)

        }
    }
}
